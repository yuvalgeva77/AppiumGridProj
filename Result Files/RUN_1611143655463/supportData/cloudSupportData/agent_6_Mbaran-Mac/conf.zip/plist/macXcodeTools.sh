#!/bin/sh

userName=$1

if [[ -z "$userName" ]]
then
	echo "Missing a user name! Exiting."
	exit -4
fi

echo "Check first launch status of XCode"
sudo xcodebuild -checkFirstLaunchStatus

echo "Handle first launch of XCode (using xcodebuild -runFirstLaunch) - install additional tools, if required by Xcode to run. This is required after installing a new XCode version."
sudo xcodebuild -runFirstLaunch

echo "Accept XCode license"
sudo xcodebuild -license accept