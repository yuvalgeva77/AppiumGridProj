#!/bin/sh

userName=$1

if [[ -z "$userName" ]]
then 
	echo "Missing a user name! Exiting."
	exit -4
fi

user_in_output=`dscacheutil -q user | grep ^name | grep $userName `
user_folder_in_output=`dscacheutil -q user | grep ^dir | grep /Users/$userName`
echo "user in output: $user_in_output"
if [[ -z "$user_in_output" ]]
then
  echo "User doesn't appear in existing users."
else 
  echo "Output for existing user: $user_in_output" 
fi

if [[ -z "$user_folder_in_output" ]]
then
  echo "User folder doesn't appear in existing users."
else
  echo "User folder exists: $user_folder_in_output"
fi

if [[ -n "$user_folder_in_output" ]]
then
  # find all files under the user folder whose owner is not the user we create.
  #    -user <USER> : owner is USER
  #    \! : negates the condition
  if [[ -n `find /Users/$userName \! -user $userName` ]]
  then
    echo "User folder of  includes items not owned by it!"
    chown -R $userName /Users/$userName
  else
    echo "No need to change owner for the user folder"
  fi
fi

if [[ -n "$user_in_output" ]] && [[ -n "$user_folder_in_output" ]]
then
  echo "The user exists with a valid user home folder path. No need to do anything."
  exit 0
fi 

if [[ -z "$user_in_output" ]] && [[ -z "$user_folder_in_output" ]]
then
  echo "User doesn't seem to exist - will be created."
else
  echo "User or it's home folder exist, but not both. User won't be created due to invalid state. Please remove the user account and the user's home folder and try again."
  exit -3
fi 
# UNUSED GROUP
gid=`dscl . -list /groups PrimaryGroupID | awk '{ print 1+$2  }' | sort -n | tail -n 1`

echo "Result of checking for the next available Group ID: $gid"

# CHECK USER ID EQUAL TO THIS GID EXISTS - shouldn't exist
outputUidCheck=`dscl . -search /users uid $gid`

echo "Result of checking for a user with uid that is equal to the selected gid: '$outputUidCheck' <- should be empty"

if [[ -n "`echo $outputUidCheck | grep $gid`" ]]
then 
	echo "A user ID  that is equal to the found group ID already exists. " 
	exit -2
else 
	echo "===="
	echo "Start creating the User"
	echo "===="
fi

#CREATE THE USER
echo "CREATING a new group with ID $gid"
dscl . -create /Groups/$userName PrimaryGroupID $gid

echo "CREATING a new user with ID $gid (same as the group ID)"
dscl . -create /Users/$userName UniqueID $gid

echo "CREATING set the user group ID to $gid"
dscl . -create /Users/$userName PrimaryGroupID $gid

echo "CREATING set the home folder path for the user"
dscl . -create /Users/$userName NFSHomeDirectory /Users/$userName

echo "CREATING set this user account to be hidden in GUI login"
dscl . -create /Users/$userName IsHidden 1

echo "CREATING generate the home folder for the user"

mkdir /Users/$userName
if [[ -n `find /Users/$userName \! -user $userName` ]]
then
    echo "$userName folder includes items not owned by it. Change the owner recursively."
    chown -R $userName /Users/$userName
fi

